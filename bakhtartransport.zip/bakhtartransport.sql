-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2022 at 10:18 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bakhtartransport`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(22) COLLATE utf8mb4_persian_ci NOT NULL,
  `password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`) VALUES
('alireza', 4321);

-- --------------------------------------------------------

--
-- Table structure for table `buslist`
--

CREATE TABLE `buslist` (
  `carnumber` int(22) NOT NULL,
  `name` varchar(22) NOT NULL,
  `amountchair` int(12) NOT NULL,
  `movehour` varchar(44) NOT NULL,
  `cnumberd` int(12) NOT NULL,
  `cnumbert` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buslist`
--

INSERT INTO `buslist` (`carnumber`, `name`, `amountchair`, `movehour`, `cnumberd`, `cnumbert`) VALUES
(1, 'bli77', 44, '3am', 0, 0),
(2, 'bus34', 44, '5am', 0, 0),
(3, 'bus7', 34, '1am', 0, 0),
(4, 'bus7', 65, '1am', 0, 0),
(5, 'ddsf5', 67, '34', 0, 0),
(6, 'bus7', 40, '5am', 0, 0),
(14, 'bbb5455', 45, '7pm', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(22) COLLATE utf8mb4_persian_ci NOT NULL,
  `emailaddres` varchar(34) COLLATE utf8mb4_persian_ci NOT NULL,
  `subject` varchar(44) COLLATE utf8mb4_persian_ci NOT NULL,
  `message` mediumtext COLLATE utf8mb4_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `emailaddres`, `subject`, `message`) VALUES
(5, 'Ø¹Ù„ÛŒ Ø±Ø¶Ø§', 'alirezaalirezakhan.ramazani666@gma', 'oodd', 'ddsddsddssdddd'),
(6, 'alireza', 'aramazani666@gmail.com', 'Ø¢Ø¨ Ù‡ÙˆØ§', 'Ù…Ø®ÙˆØ§Ø³ØªÙ…  Ø¯Ø± Ø¨Ø§Ø±Ù‡ Ø¢Ù‘Ø¨ Ù‡ÙˆØ§ Ù…Ø¹Ù„ÙˆÙ…Ø§Øª Ø¨Ú¯ÛŒØ±Ù…'),
(7, 'alireza', 'i666@gmail.com', 'Ø¢Ø¨ Ù‡ÙˆØ§', 'rtlrktlrktlrkkr'),
(9, 'hossian', 'hossain77@gmail.com', 'bbbbbbbcccc', 'what id up ');

-- --------------------------------------------------------

--
-- Table structure for table `listdriver`
--

CREATE TABLE `listdriver` (
  `cardnumberdiver` int(12) NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_persian_ci NOT NULL,
  `fathername` varchar(32) COLLATE utf8mb4_persian_ci NOT NULL,
  `lastname` varchar(32) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `phone` varchar(22) COLLATE utf8mb4_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `listdriver`
--

INSERT INTO `listdriver` (`cardnumberdiver`, `name`, `fathername`, `lastname`, `phone`) VALUES
(343433, 'dsds', 'sds', 'eee', '0765948688'),
(545454, 'aaaa', 'ddddd', 'fffff', '0777737444'),
(545465, 'fgfgf', 'fgfgfg', 'fgfgf', '0759585874');

-- --------------------------------------------------------

--
-- Table structure for table `traveler`
--

CREATE TABLE `traveler` (
  `cardnumber` int(12) NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `fathername` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `lastname` varchar(33) COLLATE utf8mb4_persian_ci NOT NULL,
  `phon` varchar(12) COLLATE utf8mb4_persian_ci NOT NULL,
  `chairset` int(22) NOT NULL,
  `prici` varchar(32) COLLATE utf8mb4_persian_ci NOT NULL,
  `traveltarget` varchar(44) COLLATE utf8mb4_persian_ci NOT NULL,
  `movehour` varchar(34) COLLATE utf8mb4_persian_ci NOT NULL,
  `movedate` varchar(33) COLLATE utf8mb4_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `traveler`
--

INSERT INTO `traveler` (`cardnumber`, `name`, `fathername`, `lastname`, `phon`, `chairset`, `prici`, `traveltarget`, `movehour`, `movedate`) VALUES
(7777, 'aaaaa', 'dddd', 'dddd', 'ddd', 7, '600 af', 'kabul to mazar', '5 am', '2022-03-19'),
(333333, 'ffff', 'ffff', 'fffff', '0780000009', 55, '600 af', 'kabul to mazar', '5 am', '2022-2-2'),
(354544, 'ali', 'hossian', 'amady', '0769488886', 23, '600 af', 'kabul to mazar', '4 am', '2022-4-4'),
(454544, 'dfd', 'sfdfds', 'sdsdfdsf', '0787878787', 23, '600 af', 'kabul to mazar', '9 pm', '67676565'),
(565654, 'alireza', 'ahmad', 'ahmady', '0787878787', 56, '600 af', 'kabul to mazar', '4 am', '2022-12-23'),
(787879, 'kjhlk', 'kjhlkhli', 'lkhlkhlkh', '0778785565', 23, '600 af', 'mazar to kabul', '4 pm', '89797978'),
(4544456, 'dfdgd', 'dddfdf', 'dfds', '0786546655', 64, '600 af', 'kabul to mazar', '4 am', '2022-2-31'),
(5656444, 'ffff', 'ffff', 'dddddd', '0785948666', 33, '600 af', 'mazar to kabul', '9 pm', '2022-2-2'),
(34343434, 'rtrtr', 'rrtr', 'ert', '0789876543', 32, '600 af', 'kabul to mazar', '10 pm', '2023-5-4'),
(45446556, 'safd', 'dfdf', 'dfsdfd', '0796857755', 12, '600 af', 'kabul to mazar', '4 am', '2022-1-3'),
(77556565, 'ali', 'sakhy', 'ahmady', '0765948666', 23, '600 af', 'kabul to mazar', '4 am', '2022-3-3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`password`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `password` (`password`);

--
-- Indexes for table `buslist`
--
ALTER TABLE `buslist`
  ADD PRIMARY KEY (`carnumber`),
  ADD KEY `fk1` (`cnumberd`),
  ADD KEY `fk2` (`cnumbert`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emailaddres` (`emailaddres`);

--
-- Indexes for table `listdriver`
--
ALTER TABLE `listdriver`
  ADD PRIMARY KEY (`cardnumberdiver`);

--
-- Indexes for table `traveler`
--
ALTER TABLE `traveler`
  ADD PRIMARY KEY (`cardnumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buslist`
--
ALTER TABLE `buslist`
  MODIFY `carnumber` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
