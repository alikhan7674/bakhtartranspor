<script type="text/javascript">
  
function login()
  {
    var uname = document.getElementById("username").value;
    var pwd = document.getElementById("password").value;
    if(uname =='')
    {
      alert("please enter user name.");
    }
    else if(pwd=='')
    {
          alert("enter the password");
    }
    else if(!filter.test(uname))
    {
      alert("Enter valid email id.");
    }
    else if(pwd.length < 6 || pwd.length > 6)
    {
      alert("Password min and max length is 6.");
    }
    else
    {
  alert('You are sucsessfuly  login');
  
      }
  }


</script>
<?php
$con=mysqli_connect("localhost","root","","bakhtartransport") or die("dont conected to the server") ;
session_start();

if (isset($_POST['username'])) {
  $user=@filter_var($_POST['username'],FILTER_SANITIZE_STRING);
  $pass=@filter_var($_POST['password'],FILTER_SANITIZE_STRING);
  $check="select * from admin where name='$user' and password='$pass';";
  $result=mysqli_query($con,$check);
  $check_admin=mysqli_num_rows($result);

  if ($check_admin==0) {
    echo "<script>alert('رمز و یا نام کاربری شما اشتباه است');</script>";
        


  }else{
      $_SESSION['user']=$user;

  header("location:hom.php");
}
}

?>
<?php
if (isset($_POST['logout'])) {
  session_destroy();
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet"/>	
<style type="text/css">
  body{background-color: lightgray}

      @media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}

@import url(http://fonts.googleapis.com/css?family=Raleway);
h2{
background-color: #FEFFED;
padding: 30px 35px;
margin: -10px -50px;
text-align:center;
border-radius: 10px 10px 0 0;
}
hr{
margin: 10px -50px;
border: 0;
border-top: 1px solid #ccc;
margin-bottom: 40px;
}
div.containers{
width: 900px;
height: 610px;
margin:35px auto;
font-family: 'Raleway', sans-serif;
margin-top: 100px;
margin-left: 600px;
background-color: lightgray;
}

div.main{
  background: lightgray;
width: 400px;
padding: 10px 50px 25px;
border: 2px solid gray;
border-radius: 10px;
font-family: raleway;
float:left;
margin-top:50px;
}
input[type=text],input[type=password]{
width: 100%;
height: 40px;
padding: 5px;
margin-bottom: 25px;
margin-top: 5px;
border: 2px solid #ccc;
color: #4f4f4f;
font-size: 16px;
border-radius: 5px;
}
label{
color: #464646;
text-shadow: 0 1px 0 #fff;
font-size: 14px;
font-weight: bold;
background: lightgray;
color: blue;
}
center{
font-size:32px;
}
.note{
color:red;
}
.valid{
color:green;
}
.back{
text-decoration: none;
border: 1px solid rgb(0, 143, 255);
background-color: rgb(0, 214, 255);
padding: 3px 20px;
border-radius: 2px;
color: black;
}
input[type=button]{
font-size: 16px;
background: linear-gradient(#ffbc00 5%, #ffdd7f 100%);
border: 1px solid #e5a900;
color: #4E4D4B;
font-weight: bold;
cursor: pointer;
width: 100%;
border-radius: 5px;
padding: 10px 0;
outline:none;
}
input[type=button]:hover{
background: linear-gradient(#ffdd7f 5%, #ffbc00 100%);
}
.main .btn
   {
    width:80px; height:32px; outline:none; 
     font-weight:bold; border:1px solid #27a465; text-shadow: 0px 0.5px 0.5px #fff;  
    border-radius: 2px; font-weight: 600; color: #27a465; letter-spacing: 1px; font-size:14px; -webkit-transition: 1s; -moz-transition: 1s;
     transition: 1s;
     color: black;
   }
  
   .main .btn:hover
   {
    background-color:#27a465; outline:none;  border-radius: 6px; color:#f1f1f1; border:1px solid #f1f1f1;
   }


@media screen and (max-width: 1000px) {
div.containers{
margin-left: 300px;
}}

@media screen and (max-width: 800px) {
div.containers{
margin-left: 90px;
}}
@media screen and (max-width: 500px) {
div.containers{
margin-left: 12px;
}}
</style>
		
	
  </head>
  <body>	
	<header id="header" >
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">                        <img src="log.png">

                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                  
                </div>        
                <div class="collapse navbar-collapse navbar-right">
                                            <ul class="nav navbar-nav">
                                            <li><a href="login.php" style="color: #99">وردشدن </a>

                                           <li><a href="contact.php">ارتباط با ما</a></li> 
                                                <li><a href="agent.php">نماینده گی </a></li> 

                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>
 
                                                <li class="active"><a href="index.php">اصلی</a></li>

                                         </li>
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->   
    </header><!--/header--> 

<div class="containers">
<div class="main">
<h2 style="background-color:lightgray; color: blue;font-weight: bold;">welcome to login page website </h2>
<form id="form_id" method="post" name="myform" action="">
<label>User Name :</label>
<input type="text"  id="username" name="username" required=" required" />
<label>Password :</label>
<input type="password"  id="password" name="password" required="required" />
<input type="submit" value="Reset" onclick="clearFunc()" class="btn" onclick="login();" />
    <input type="submit" value="Login" class="btn"  />

</form>
</div>
</div>

  
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script type="text/javascript">
 
    function clearFunc()
    {
        document.getElementById("username").value="";
        document.getElementById("password").value="";
    }   

    </script>
    <script src="js/jquery-2.1.1.min.js">
    	   

    </script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>
