<?php
include("conect.php");
include("session.php");

$getdelet=$_GET["delet"];

$seedit="SELECT * FROM `buslist` WHERE carnumber=$getdelet";
$mqur=mysqli_query($con,$seedit);
while($selcssoc=mysqli_fetch_assoc($mqur)){
               $carid=$selcssoc['carnumber'];
               $carname=$selcssoc['name'];
				$carchair=$selcssoc['amountchair'];
				
				
} 


if (isset($_POST["sub"])) {
$del="DELETE FROM `buslist` WHERE  carnumber='$getdelet' ";
$mqur=mysqli_query($con,$del);
if($mqur){
	header("location:readcar.php");
}
}
?>


<!DOCTYPE html>
<html>
<head>



	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
<style type="text/css">


	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}

form{margin-top: 200px;align-self: center;align-content:center;margin-left: 99px; }
	form table tr td{font-size: 18px; font-weight: bold;}
	form  table tr td input{width:300px; height:25px;font-size:18px; font-weight:bold;}
	h2{color: black;margin-left: 110px;}

</style>
	
</head>
<body style="background-color:rgb(217, 234, 241)">
		<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="hom.php">اصلی</a></li>
                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	

<form method="post" enctype="multipart/form-data"><h2>مطمین هستید که حذف می کنید 
</h2>
<table><tr><td>

	نمبر بس  :</td><td>
	<input type readonly  placeholder="نمبر بس" value="<?php echo $carid	; ?>"></td></tr>
	<tr><td>
نام  بس  :</td><td>
  <input type readonly placeholder="نام بس" value="<?php echo $carname; ?>" ></td></tr>
  <tr><td>
  تعداد چوکی بس  :</td><td>
  <input readonly placeholder="تعداد چوکی بس" value=" <?php echo $carchair; ?>"></td></tr>
  



     <tr><td></td><td><br><input  type="submit" name="sub" value="خذف کردن" 
	 style="width: 130px;height: 50px;border-radius: 30px;border-top-right-radius: 30px;border-top-left-radius: 30px;
	background-color: #cc9933; font-size: 17px; font-weight: bold;font-size: 20px;" 
	 ></td></tr>
	 
    
     </table>
</form>
  <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
</body>

</html>
