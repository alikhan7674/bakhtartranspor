	<?php

$con=mysqli_connect("localhost","root","","bakhtartransport") or die("dont conected to the server") ;
?>