<?php 

include("conect.php");
include("session.php");

$getid=$_GET['edit'];
$seedit="SELECT * FROM `admin` WHERE password='$getid' ";
$mqur=mysqli_query($con,$seedit);
while($selcssoc=mysqli_fetch_assoc($mqur)){
                   $username=$selcssoc['name'];

               $password=$selcssoc['password'];
               
                
} 

   
if (isset($_POST["uppassword"])) {
    

                    $uppassword=$_POST['uppassword'];
                    $upname=$_POST['upname'];
                    

    
                

    $upsele="UPDATE `admin` SET name='$upname',password='$uppassword' WHERE password='$password' ";

                    $mqur=mysqli_query($con,$upsele);
                    if ($mqur) {
                    header("location:updateuser.php");
                   }else{
                  echo "dont uppadted!";
       }
                    
                }


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
		
<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}


</style>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">ویرایش کردن ادمین</h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="hom.php">اصلی</a></li>
                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
			
			
			<div class="container">
				<div class="row">
								
					
					
					
					<div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.6s"  ">  	
					    <div id="sendmessage">پیام شما موفقانه ازسال شد . تشکر از شما!</div>
                        <div id="errormessage"></div>
                        <form action="" method="post" role="form" class="contactForm"  >
                            <div class="form-group"> 
                            نام :
                             <input type="text" class="form-control" name="upname" id="name" placeholder="نام " required="required" value="<?php echo $username; ?>"/>
                              <div class="validation"></div>
                                </div>
                                <div class="form-group">رمز: 
                 <input type="number" name="uppassword" class="form-control" id="cardnumber" placeholder="نمبر تذکره " data-rule="minlen:4" required="required" value="<?php echo $password; ?>" />
                                        <div class="validation"></div>
                                </div>
                            
                            <button type="submit" class="btn btn-theme pull-left">ویرایش کردن</button>
                        </form>
					</div>	
				</div>
		
		</div>

		
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>