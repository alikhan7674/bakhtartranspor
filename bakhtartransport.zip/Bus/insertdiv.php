<?php 
$con=mysqli_connect("localhost","root","","bakhtartransport")
 or die("dont conected to the server") ;

if(isset($_POST["cardnumber"])){
		$cardnumber=$_POST['cardnumber'];


$name=$_POST['name'];
$fname=$_POST['fname'];
$lastname=$_POST['lastname'];
$phone=$_POST['phon'];



    


echo "$phone";


      $imy="INSERT INTO `listdriver`(`cardnumberdiver`, `name`, `fathername`, `lastname`, `phone`) 
      VALUES ('$cardnumber','$name','$fname','$lastname','$phone')";
$qur=mysqli_query($con,$imy);
if($qur){
    header("location:hom.php");
}else{
    echo "dont insearted!";
}
}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
		
<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}


</style>
<script type="text/javascript">
     function validate() {



        var cardnumber=document.getElementById("cardnumber").value;
var name=document.getElementById("name").value;
var fname=document.getElementById("fname").value;
var lastname=document.getElementById("lastname").value;
var phon=document.getElementById("phon").value;
var validphon= new RegExp("07[0123456789][0-9]{7}");
var valiname= new RegExp("[A-z]");
var valifname= new RegExp("[A-z]");
var valilastname= new RegExp("[A-z]");
var digit=new RegExp("[0-9]");
var valphonp= new RegExp("[A-z]");


var valid=true;
       if (cardnumber=="") {

  document.getElementById("cardnumber").style.backgroundColor="rgb(250,160,130)";
  valid=false;



       }else if (cardnumber.length<6|cardnumber.length>8) {
        alert("اندازه شماره شما درست نیست ");

}

else{

document.getElementById("cardnumber").style.backgroundColor="white ";


}


     if (name=="") {

  document.getElementById("name").style.backgroundColor="rgb(250,160,130)";
valid=false;


       }else if (name.length<3) {

alert("کمتر از سه حروف است ");
valid=false;

}else if (name.indexOf(" ")>-1) {

alert("فاصله اجازه نیست ");
valid=false;


}else if (!valiname.test(name)) {
alert("عدد شامل نام شده نمیتواند ");

valid=false;

}else  if (digit.test(name)) {
alert("عدد شامل نام شده نمیتواند ");


valid=false;

}



else{

document.getElementById("name").style.backgroundColor="white ";


}
        if (fname=="") {

  document.getElementById("fname").style.backgroundColor="rgb(250,160,130)";
          valid=false;


       

}else if (fname.length<3) {

alert("کمتر از سه حروف است ");
valid=false;



}else if (fname.indexOf(" ")>-1) {

alert("فاصله اجازه نیست ")
valid=false;


}else if (!valifname.test(fname)) {
alert("عدد شامل نام شده نمیتواند ");


valid=false;

}

else  if (digit.test(fname)) {
alert("عدد شامل نام شده نمیتواند ");


valid=false;

}

else{

document.getElementById("fname").style.backgroundColor="white ";


}

        if (lastname=="") {

  document.getElementById("lastname").style.backgroundColor="rgb(250,160,130)";

              valid=false;

       }else if (lastname.length<3) {
alert("تخلص شما کمتر از سه حروف است ");
valid=false;



}else if (lastname.indexOf(" ")>-1) {

alert("فاصله اجازه نیست ");
  document.getElementById("lastname").style.backgroundColor="rgb(250,160,130)";

valid=false;


}else if (!valilastname.test(lastname)) {
    document.getElementById("lastname").style.backgroundColor="rgb(250,160,130)";

alert("عدد شامل نام شده نمیتواند ");


valid=false;

}else  if (digit.test(lastname)) {
    document.getElementById("lastname").style.backgroundColor="rgb(250,160,130)";

alert("تخلص عدد شده نمیتواند");


valid=false;

}


else{

document.getElementById("lastname").style.backgroundColor="white ";


}



       if (phon=="") {

  document.getElementById("phon").style.backgroundColor="rgb(250,160,130)";

              valid=false;

       }else  if (valphonp.test(phon)) {
    document.getElementById("phon").style.backgroundColor="rgb(250,160,130)";

alert("عدد اجازه نیست  به شماره تلقن ");


valid=false;

}



       else if (phon.length<10|phon.length>10) {
          document.getElementById("phon").style.backgroundColor="rgb(250,160,130)";

        alert("اندازه شماره نادرست است ");

valid=false;


}else if (!validphon.test(phon)) {
    document.getElementById("phon").style.backgroundColor="rgb(250,160,130)";

alert("فرامت شماره درست نیست ");

valid=false;

}


else{

document.getElementById("phon").style.backgroundColor="white ";


}
window.setTimeout(hidspan,5000);
return valid;


}



function hidspan() {

  

document.getElementById("carnumber").style.backgroundColor="white ";
document.getElementById("chiar").style.backgroundColor="white ";
document.getElementById("bus").style.backgroundColor="white ";
document.getElementById("movehour").style.backgroundColor="white ";

 

}




</script>
  </head>

  <body>
  	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">اضافه کردن بس </h1>
                </div>              
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="hom.php">اصلی</a></li>
                        
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->       
    </header><!--/header--> 
            
            
	
			
			<div class="container">
				<div class="row">
								
					
					
					
					<div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.6s"  ">  	
					    <div id="sendmessage">پیام شما موفقانه ازسال شد . تشکر از شما!</div>
                        <div id="errormessage"></div>
                        <form action="" method="post" role="form" class="contactForm" enctype="multipart/form-data" onsubmit="return ( validate());">
                                <div class="form-group">نمبر تذ کرده: 
                                        <input type="number" name="cardnumber" class="form-control" id="cardnumber" placeholder="نمبر تذکره " data-rule="minlen:4"  />
                                </div>
                                <div class="form-group"> 
                            نام :
                                        <input type="text" class="form-control" name="name" id="name" placeholder="نام " autocomplete="off" />
                                </div>
                                <div class="form-group">نام پدر  :
                                        <input type="text" class="form-control" autocomplete="off" 
                                         name="fname" id="fname" placeholder="نام پدر" data-rule="minlen:4"  />
                                </div>
                                <div class="form-group">تخلص:
                                        <input type="text" class="form-control" name="lastname"  autocomplete="off" 
                                        id="lastname" placeholder="تخلص   " />
                                        
                                </div>
                               
                            
                                <div class="form-group">شماره تماس   :
                                        <input type="tel" class="form-control"  autocomplete="off" 
                                        name="phon" id="phon" placeholder="شماره تماس  "/>
                                 
                                </div>
                               
                            
                            <button type="submit" class="btn btn-theme pull-left">راجستر کردن</button>
                        </form>
					</div>	
				</div>
		
		</div>

		
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>