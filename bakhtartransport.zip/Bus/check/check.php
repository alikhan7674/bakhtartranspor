<?php
$con=mysqli_connect("localhost","root","","bakhtartransport") or die("dont conected to the server") ;

$username="select username from admin"
if(isset($_POST["submit"])){
   if (isEmpty($_POST["name"]) || isEmpty($_POST["password"])) {
   	header("location:login.php?empty=true");
   	exit;
   }elseif ($_POST["name"]==$) {
   	# code...
   }


}

?>