
<?php 
include("session.php");

include("conect.php");


?>





<!DOCTYPE html>
<html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
<style type="text/css">

<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}

#con{margin-top: 0px;}

#con .container {margin-top: 86px;left: 0px ; width:100%;}
#con .container .table tr td{border-top: 2px solid lightgray;border-bottom: 2px solid lightgray;border-right: 2px solid lightblue}
#con .container .table tr th{font-size: 22px; font-weight: bold;background-color: lightgray;text-align: center;}
#con .container .table tr td{font-size: 14px; font-weight: bold;border:2px solid lightblue;background-color:#def;}
#con .container .table{border: 4px solid lightblue; text-align: center;}
#con .container h1{position: absolute;top: 14px;border-radius: 20px; border: 2px solid lightblue;
	margin-left: 20px;
	width: 60%; background-color: blue}

  table tr td a{font-weight: bold;}

</style>
 
 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body style="background-color:rgb(245, 241, 255);">
  
</head>
<body >
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">تغییر رمز عبور </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="hom.php">اصلی</a></li>
                        
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
			<div id="con">
	
<div class="container">
  	<h1>صفخه مدیریت بس </h1>

  <table class="table table-bordered">

<tr>
				 <th>عملیات </th><th>نام </th><th>پسورد </th>  </tr>
		<?php

		$sel="SELECT * FROM  `admin` ";
          $mysdisplay=mysqli_query($con,$sel);

            while($row=mysqli_fetch_array($mysdisplay)){
				$name=$row['name'];
               $password=$row['password'];
				
       
				echo "<tr class='active'> 
				<td><a href='edituser.php?edit=$password'>جدید کردن یوزر</a></td>
      			
				<td>".$name."</td>
				<td>".$password."</td>
				
				</tr>";
			}
		

		?>

</table>
</div>
</div>
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
</body>
</html>