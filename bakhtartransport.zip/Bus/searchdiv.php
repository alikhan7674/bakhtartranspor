<?php 

$con=mysqli_connect("localhost","root","","bakhtartransport") ;
if(isset($_POST['search'])){
$value_search=$_POST['search'];
echo $value_search;
	if(empty($_POST['search']))
		header("location:readderiver.php");

}
?>




<!DOCTYPE html>
<html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
<style type="text/css">

<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}

#con{margin-top: px;width:100%;}

#con .container {margin-top: 97px;left: 0px ; width:100%;}
#con .container table tr td{border-top: 2px solid lightgray;border-bottom: 2px solid lightgray;border-right: 2px solid lightblue}
#con .container table tr th{font-size: 22px; font-weight: bold;background-color: #eee; height: 55px;text-align: center;}
#con .container table tr td{font-size: 14px; font-weight: bold;border:2px solid lightblue;height: 35px;}
#con .container .table{border: 2px solid lightgray;width: 100%;}
#con .container h1{position: absolute;top: 14px;border-radius: 20px; border: 2px solid lightblue;

  margin-left: 20px;
  width: 60%; background-color: blue}

 .container table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  text-align: center;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.container a button{top: 30px;margin-left:0px;}
.search{position: absolute;margin-top: -45px;margin-left: 740px;}
.search input{font-size: 13px; font-weight: bold;border: 2px solid lightgray;height: 35px;outline: 1px solid lightgray}
.search form button{font-size: 18px; font-weight: bold;height: px;outline: 1px solid lightgray}
</style>
 
 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body style="background-color:rgb(245, 241, 255);">
  
</head>
<body >
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">مشخضات در باره  <?php echo $value_search; ?> </h1>
                    
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="readderiver.php">برگشت </a></li>
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
			<div id="con">
	
<div class="container">
  	<h1>صفخه مدیریت بس </h1>

  <table>


				
<tr>
         <th>عملیات </th><th>شماره تماس</th><th>نمبر تذکرده</th>  <th>تخلص </th><th>نام پدر </th><th>نام </th> </tr>

		<?php

		if(isset($_POST['search'])){
$value_search=$_POST['search'];
$query="select * from listdriver  where name LIKE '%".$value_search."%'";
}
$result=mysqli_query($con,$query);

            while($row=mysqli_fetch_array($result)){
				$cardnumberdiver=$row['cardnumberdiver'];
               $name=$row['name'];
				$fathername=$row['fathername'];
				$lastname=$row['lastname'];
				     $phon=$row['phone'];
      
        
				echo "<tr > <td>
				<a href='cardelet.php?delet=$cardnumberdiver'>حدف کردن</a></td>
				
        <td>".$phon."</td>
        <td>".$cardnumberdiver."</td>

                <td>".$lastname."</td>

        <td>".$fathername."</td>

                <td>".$name."</td>


				
				</tr>
				";
			
		
			}
			
				
		

		?>

</table>
</div>
</div>



 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
</body>
</html>

