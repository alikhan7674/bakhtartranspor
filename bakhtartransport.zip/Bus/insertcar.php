<?php 
$con=mysqli_connect("localhost","root","","bakhtartransport")
 or die("dont conected to the server") ;

include("session.php");

if(isset($_POST["bus"])){


$bus=$_POST['bus'];
$chiar=$_POST['chiar'];

$movehour=$_POST['movehour'];

    
echo "$bus";

      $imy="INSERT INTO `buslist`( `name`, `amountchair`, `movehour`)
       VALUES ('$bus','$chiar','$movehour')";
       echo "$imy";
$qur=mysqli_query($con,$imy);

if($qur){
    header("location:hom.php");
}else{
    echo "dont insearted!";
}


}


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
		
<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}


</style>
<script type="text/javascript">
    function validate() {



var name=document.getElementById("bus").value;
var chiar=document.getElementById("chiar").value;


var valid=true;
       

       if ( document.getElementById("hour").value=="select hour") {
    document.getElementById("hour").style.backgroundColor="rgb(250,160,130)";
    valid=false;

}else  {
      document.getElementById("hour").style.backgroundColor="white";


}
     if (chiar=="") {

  document.getElementById("chiar").style.backgroundColor="rgb(250,160,130)";
valid=false;


       }else if (chiar.length>2||chiar>65) {

              alert("!!!!این نمبر وجود ندارد  ");
              valid=false;


       }else {

      document.getElementById("chiar").style.backgroundColor="white";

}


        if (name=="") {

  document.getElementById("bus").style.backgroundColor="rgb(250,160,130)";

              valid=false;

       } else if (name.length<9) {
        alert("اندازه نمبر پلیت درست نیست ");
        valid=false;


}else {

      document.getElementById("bus").style.backgroundColor="white";

}




window.setTimeout(hidspan,5000);
return valid;


}



function hidspan() {

  

document.getElementById("carnumber").style.backgroundColor="white ";
document.getElementById("chiar").style.backgroundColor="white ";
document.getElementById("bus").style.backgroundColor="white ";
document.getElementById("movehour").style.backgroundColor="white ";

 

}


</script>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">اضافه کردن بس </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="hom.php">اصلی</a></li>
                        
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
			
			
			<div class="container">
				<div class="row">
								
					
					
					
					<div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.6s"  ">  	
					    <div id="sendmessage">پیام شما موفقانه ازسال شد . تشکر از شما!</div>


                          <form  method="post" role="form" class="contactForm"   name="myForm" onsubmit=" return (validate());"   >

                                <div class="form-group">

                        
                                      
                            نام و نمبر پلیت بس
                                        <input type="text" class="form-control" id="bus" name="bus" id="bus" placeholder="نام بس" /  
                                        autocomplete="off"><span id="n"></span>
                                      

                                    تعداد چوکی :
                                        <input type="number"  id="chiar"  autocomplete="off" 
                                        class="form-control" name="chiar" id="chiar" placeholder="تعداد چوکی بس" data-rule="minlen:4"  />
                                        <span id="chn"></span>


                                        ساعت حرکت :
                                         <select name="hour" id="hour" style="width: 360px;"      class="form-control"        >
                                    <option value="select hour" >  select hour</option>
                                          <option >
                                            4 am
                                          </option>
                                           <option>
                                            8 am
                                          </option>
                                           <option>
                                            4 pm
                                          </option>
                                           <option>
                                            8 pm
                                          </option>
                                           

                                       
                                      </select> <br>

                                
                            <input type="submit" class="btn btn-theme pull-left" id="submit" value="اراجستر کردن " 
                                                                      class="form-control" style="width: 120px;" > 

                                    
                    
                                </div>
                            
                        </form>
					</div>	
				</div>
		
		</div>

		
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>