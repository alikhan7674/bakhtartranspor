<?php
include("session.php");

include("conect.php");

$getdelet=$_GET["delet"];

$seedit="SELECT * FROM assistantlist WHERE cardnumberassist=$getdelet ";
$mqur=mysqli_query($con,$seedit);
while($selcssoc=mysqli_fetch_assoc($mqur)){
               $card=$selcssoc['cardnumberassist'];
               $name=$selcssoc['name'];
				$fname=$selcssoc['fathername'];
				 $lastname=$selcssoc['lastname'];
				 $phone=$selcssoc['phone'];

				
} 

   if (isset($_POST['sub'])) {
$del="DELETE FROM `assistantlist` WHERE cardnumber='$getdelet' ";
$mqur=mysqli_query($con,$del);
if($mqur){
	header("location:readassitant.php");
}
}
?>

<!DOCTYPE html>
<html>
<head>



	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
<style type="text/css">


	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}

form{margin-top: 200px;align-self: center;align-content:center;margin-left: 99px; }
	form table tr td{font-size: 18px; font-weight: bold;}
	form  table tr td input{width:300px; height:25px;font-size:18px; font-weight:bold;}
	h2{color: black;margin-left: 110px;}

</style>
	
</head>
<body style="background-color:rgb(217, 234, 241)">
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="hom.php">اصلی</a></li>
                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	

<form method="post" action=""><h2>مطمین هستید که حذف می کنید
</h2>
<table><tr><td>

	نمبر تذکره :</td><td>
	<input type readonly placeholder="نمبر تذکره " value="<?php echo $card	; ?>"></td></tr>
	<tr><td>
نام :</td><td>
  <input type readonly placeholder="نام " value="<?php echo $name; ?>" ></td></tr>
  <tr>
  	<td>
  نام پدر :</td><td>
  <input type readonly placeholder="نام پدر" value="<?php echo $fname; ?>"></td></tr>
  

<tr>
	<td>
تخلص  :</td><td>
<input type readonly value="<?php echo $lastname;?>"</td></tr>
	<td>
  شماره تماس   :</td><td>
  <input type readonly placeholder="شماره تماس"  value="<?php echo $phone; ?>"></td></tr>
     <tr><td></td><td><br><input  type="submit" name="sub" value="حذف کردن" 
	 style="width: 130px;height: 50px;border-radius: 30px;border-top-right-radius: 30px;border-top-left-radius: 30px;
	background-color: #cc9933; font-size: 17px; font-weight: bold;font-size: 20px;" 
	 ></td></tr>
	 
    
     </table>
</form>
  <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
</body>

</html>
