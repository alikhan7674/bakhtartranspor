

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
	<style type="text/css">
		
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}


@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
padding-top: 22px;

}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
padding-top: 22px;

}}

@media screen and (max-width: 700px) {
.wow h2{
font-size:19px;
text-align: center;
margin-top: 90px;
}}
@media screen and (max-width: 600px) {
.wow h2{
font-size:19px;
text-align: center;
margin-top: 90px;
}}
@media screen and (max-width: 1000px) {
.wow h2{
font-size:21px;

list-style-type: none;
text-align: center;
margin-top: 90px;
}}
@media screen and (max-width: 500px) {
.wow h2{
font-size:19px;
text-align: center;
margin-top: 90px;
} 
}
@media screen and (max-width: 500px) {
.item .form-group {
font-size:14px;
text-align: center;
width: 40px; height: 40px;
margin-top: -80px;padding: 10px;
} 
}

@media screen and (max-width: 500px) {
.item .form-group button {
font-size:14px;
text-align: center;
 margin-top: 68px;
 margin-left:80px;
} 
}
.item .form-group button:hover{background-color: white;font-weight: bold;color: #a9f;}
.item .form-group button{background-color: #fff;}
.coment .name li{list-style-type:none; }
	</style>
    <script type="text/javascript">
        


         var d= new  Date();
        document.write(d.getFullYeay() +"/"+ (d.getMonth()+1) +"/"+ d.getDate());
    </script>

  </head>
  <body>	
	<header id="header" >
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">                        <img src="log.png">

                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
									
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                    	                        <li><a href="login.php" style="color: #99">وردشدن </a>

                        <li><a href="contact.php">ارتباط با ما</a></li> 

                        <li><a href="#our-team">نماینده گی </a></li> 
                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>
 
                                                <li><a href="#gallery">تصاویر</a></li>

                                                <li class="active"><a href="#">اصلی</a></li>

                                         </li>
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	<div class="slider">		
		<div id="about-slider">
			<div id="carousel-slider" class="carousel slide" data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators visible-xs">
					<li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-slider" data-slide-to="1"></li>
					<li data-target="#carousel-slider" data-slide-to="2"></li>
				</ol>

				<div class="carousel-inner">
					<div class="item active">						
						<img src="img/13.jpg" class="img-responsive" alt=""> 
						<div class="carousel-caption">
							<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">	
													
							</div>
							
							
						</div>
				    </div>
			
				    <div class="item">
						<img src="img/6.jpg" class="img-responsive" alt=""> 
						<div class="carousel-caption">
							<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="1.0s">								
							</div>
							<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="1.3s">								
								<p></p>
							</div>
							
						</div>
				    </div> 
				    <div class="item">
						<img src="img/22.png" class="img-responsive" alt=""> 
						<div class="carousel-caption">
							<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">								
							</div>
							<div class="wow fadeInUp" data-wow-offset="0" data-wow-delay="0.6s">								
								<p></p>
							</div>
							
						</div>
				    </div> 
				</div>
				
				<a class="left carousel-control hidden-xs" href="#carousel-slider" data-slide="prev">
					<i class="fa fa-angle-left"></i> 
				</a>
				
				<a class=" right carousel-control hidden-xs"href="#carousel-slider" data-slide="next">
					<i class="fa fa-angle-right"></i> 
				</a>
			</div> <!--/#carousel-slider-->
		</div><!--/#about-slider-->
	</div><!--/#slider-->
	 <div id="gallery">
        <div class="container">
            <div class="text-center">
                <h3>تصاویر ها</h3>
                <p>بس ها برای <br>شما مشتریان </p>
            </div>
            <div class="row">
                <figure class="effect-chico">                       
                    <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/9.jpg" class="flipLightBox">
                        <img src="img/work/9.jpg" class="img-responsive" alt="">
                        </a>                        
                    </div>
                </figure>
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/2.jpg" class="flipLightBox">
                        <img src="img/work/2.jpg" class="img-responsive" alt="">
                        </a>
                    </div>
                </figure>   
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/3.jpg" class="flipLightBox">
                        <img src="img/work/3.jpg" class="img-responsive" alt="">
                        </a>
                    </div>
                </figure>
                <figure class="effect-chico">
                    <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                        <a href="img/work/4.jpg" class="flipLightBox">
                        <img src="img/work/4.jpg" class="img-responsive" alt="">
                        </a>
                    </div>  
                </figure>
            </div>
        </div>
        <div class="gallery">
            <div class="container">
                <div class="row">
                    <figure class="effect-chico">
                        <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                            <a href="img/work/5.jpg" class="flipLightBox">
                            <img src="img/work/5.jpg" class="img-responsive" alt="">
                            </a>
                        </div>
                    </figure>   
                    <figure class="effect-chico">
                        <div class="col-md-3 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                            <a href="img/work/6.jpg" class="flipLightBox">
                            <img src="img/work/6.jpg" class="img-responsive" alt="">
                            </a>
                        </div>
                    </figure>   
                    <figure class="effect-chico">
                        <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                            <a href="img/work/7.jpg" class="flipLightBox">
                            <img src="img/work/7.jpg" class="img-responsive" alt="">
                            </a>
                        </div>
                    </figure>   
                    <figure class="effect-chico">
                        <div class="col-md-3 wow fadeInDown" data-wow-offset="0" data-wow-delay="0.3s">
                            <a href="img/work/8.jpg" class="flipLightBox">
                            <img src="img/work/8.jpg" class="img-responsive" alt="">
                            </a>
                        </div>
                    </figure>
                </div>
            </div>
        </div>
    </div><!--/#gallery-->
    <div id="our-team">
        <div class="container">
            <div class="text-center">
                <h3>نماینده ما</h3>
                <p>اینها در صورت مشکلات به شما کمک می کند <br>و بهترین سهولت را برای شما فراهم می سازد </p>
            </div>
            <div class="row">
                <div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/1.png" alt="">
                        <h2>حبیب الله </h2>
                        <h4>مدیر</h4>
                        <p>0770180121:شماره تماس</p>
                    </div>
                </div>
                <div class="col-md-4 wow bounceInDown" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/2.png" alt="">
                        <h2>محمد </h2>
                        <h4>معاون</h4>
                        <p>0799055800 :شماره تماس</p>
                    </div>
                </div>
                <div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/3.png" alt="">
                        <h2>سخی </h2>
                        <h4>خلیفه </h4>
                        <p> 0747350839:شماره تماس</p>
                    </div>
                </div>  
            </div>
        </div>
	
		<div class="social-icon">
			<div class="container">
				<div class="col-md-6 col-md-offset-3">						
					<ul class="social-network">
						<li><a href="http://www.Facebook.com" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https//www.twitter.com" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="https//Google.com" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="https//linkedin.com" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="https//ytube.com" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
						<li><a href="https//dribbble.com" class="dribbble tool-tip" title="Dribbble"><i class="fa fa-dribbble"></i></a></li>
						<li><a href="https//pinterest.com" class="pinterest tool-tip" title="Pinterest"><i class="fa fa-pinterest-square"></i></a></li>
					</ul>						
				</div>
			</div>
		</div>						
		

	</footer>

    <script type="text/javascript">
        


       
    </script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>