<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
		
<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}

</style>
<script>
function validateForm() {
  var name = document.forms["myForm"]["name"].value;
    var email = document.forms["myForm"]["email"].value;
  var subject = document.forms["myForm"]["subject"].value;
  var message = document.forms["myForm"]["message"].value;
  var emails= new RegExp("[A-z][A-z0-9]{5,32}@[A-z]{5,32}.[A-z]{2,5}");
  var valname= new RegExp("[A-z]");
  var valsub= new RegExp("[A-z]");
var valmes= new RegExp("[A-z]");
var digit=new RegExp("[0-9]");



    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

  var validation=true;
  if (name == "") {
      document.getElementById("name").style.backgroundColor="rgb(250,160,130)";

    validation= false;
  }else if (digit.test(name)) {
      alert("نام عدد شده نمیتواند ");


validation=false;

}else if (name.length<3) {
      document.getElementById("name").style.backgroundColor="rgb(250,160,130)";


alert("کمتر از سه حروف است ");
validation=false;

}else if (name.indexOf(" ")>-1) {
      document.getElementById("name").style.backgroundColor="rgb(250,160,130)";

alert("فاصله اجازه نیست ");
validation=false;


}else if (!valname.test(name)) {
alert("عدد شامل نام شده نمیتواند ");
      document.getElementById("name").style.backgroundColor="rgb(250,160,130)";


validation=false;

}else  if (digit.test(name)) {
      document.getElementById("name").style.backgroundColor="rgb(250,160,130)";

alert("عدد شامل نام شده نمیتواند ");


validation=false;

}



else{

document.getElementById("name").style.backgroundColor="white ";


}

 
   if (subject==="") {
  document.getElementById("subject").style.backgroundColor="rgb(250,160,130)";

    validation= false;


  }else if (subject.length>34) {
      document.getElementById("subject").style.backgroundColor="rgb(250,160,130)";


alert("عنوان شما بزرکتر از اندازه است ");
validation=false;

}
  else{

document.getElementById("subject").style.backgroundColor="white ";


}
 

   if (message==="") {
      document.getElementById("message").style.backgroundColor="rgb(250,160,130)";

    validation= false;


  }else if (message.length>500) {
          document.getElementById("message").style.backgroundColor="rgb(250,160,130)";


alert("مسیج شما بسیار بزرگ است ");
validation=false;

} else{

document.getElementById("message").style.backgroundColor="white ";


}
  if (email==="") {
      document.getElementById("email").style.backgroundColor="rgb(250,160,130)";

    validation= false;


  }

     else if(!emails.test(email))
    {
            document.getElementById("email").style.backgroundColor="rgb(250,160,130)";

      alert("ایمل آدرس شما کمتر از ۵ حروف است .");
      validation=false;
    } else{

document.getElementById("email").style.backgroundColor="white ";


}
    window.setTimeout(hidspan,5000);

    return validation;

}









function hidspan() {

  

document.getElementById("name").style.backgroundColor="white ";
document.getElementById("subject").style.backgroundColor="white ";
document.getElementById("email").style.backgroundColor="white ";
document.getElementById("message").style.backgroundColor="white ";

 

}

</script>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                        <li><a href="contact.php">ارتباط با ما</a></li>  
                                                <li><a href="agent.php">نماینده گی </a></li> 

                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>

                                                <li class="active"><a href="index.php">اصلی</a></li>

                                         </li>
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
		<footer>
		<div id="contact">
			<div class="container">
				<div class="text-center">
					<h3>ارتباط با ما</h3>
					<p>ما از کمک کردن برای شما بسیار خرسند هستیم </p>
				</div>
			</div>
			<div class="container">
				<div class="row">
								
					
					<div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.4s">
						<h2>ارتباط  بیشتر</h2>
						<ul>
							<li><i class="fa fa-home fa-2x"></i>دفتر مرکزی کابل, گدشته از پوهنتون نخبه گان</li><hr>


		                   <li><i class="fa fa-home fa-2x"></i> دفتر مرکزی, مزار شریف , گدشته از پوهنتون نخبه گان</li><hr>

							<li><i class="fa fa-phone fa-2x"></i>0765948666</li><hr>
							<li><i class="fa fa-envelope fa-2x"></i><a href="https://www.gemail.com">info@gmail.com</a></li>
						</ul>
					</div>
					
					<div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.6s"  ">  	
					    <div id="sendmessage">پیام شما موفقانه ازسال شد . تشکر از شما!</div>
                        <div id="errormessage"></div>
                        <form action="" method="post" role="form" class="contactForm" onsubmit="return (validateForm())" name="myForm" >
                                <div class="form-group">
                                        <input type="text" name="name" autocomplete="off" class="form-control" id="name" id="name" 
                                        placeholder="نام شما" data-rule="minlen:4" data-msg="Please enter at least 4 chars"  />
                                        <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                        <input type="email" class="form-control"
                                         autocomplete="off" name="email" id="email" 
                                         placeholder="آدرس ایمل" data-rule="email" data-msg="Please enter a valid email"  />
                                        <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                        <input type="text" class="form-control"
                                         autocomplete="off" name="subject" id="subject" placeholder="موضوع" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject"  />
                                        <div class="validation"></div>
                                </div>
                                <div class="form-group">
                                        <textarea class="form-control"  id="message" 
                                         autocomplete="off" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="لطفا پیام تان را بنویسید"
                                         ></textarea>
                                        <div class="validation"></div>
                                </div>
                            
                            <input type="submit" class="btn btn-theme pull-left" value=" ارسال کردن">
                        </form>
					</div>	
				</div>
			</div>
		</div><!--/#contact-->	
		<?php

$con=mysqli_connect("localhost","root","","bakhtartransport") or die("Please a erro occured");




if(isset($_POST["name"])){
		$name=$_POST['name'];


$email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['message'];

 $imy="INSERT INTO `contact`
     ( `name`, `emailaddres`, `subject`, `message`)

 VALUES ( '$name','$email','$subject','$message')";

$qur=mysqli_query($con,$imy);




if($qur){
    header("location:index.php");
}else{
    echo "dont insearted!";
}
}
		?>


					
		<div class="social-icon">
			<div class="container">
				<div class="col-md-6 col-md-offset-3">						
					<ul class="social-network">
						<li><a href="www.Facebook.com" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="www.twitter.com" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="Google.com" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="linkedin.com" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="ytube.com" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
						<li><a href="dribbble.com" class="dribbble tool-tip" title="Dribbble"><i class="fa fa-dribbble"></i></a></li>
						<li><a href="pinterest.com" class="pinterest tool-tip" title="Pinterest"><i class="fa fa-pinterest-square"></i></a></li>
					</ul>						
				</div>
			</div>
		</div>						
		

	</footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>