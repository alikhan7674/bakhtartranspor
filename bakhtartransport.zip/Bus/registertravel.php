


<?php 

include("conect.php");

mysqli_set_charset($con,"utf8");

if(isset($_POST["card"])){
        $card=$_POST['card'];


$name=$_POST['name'];
$fname=$_POST['fname'];
$lastname=$_POST['lastname'];
$phone=$_POST['phon'];
$chiarnumber=$_POST['chnumber'];

$prici=$_POST['prici'];
$moves=$_POST['moves'];

$hour=$_POST['hour'];
$dates=$_POST['dates'];




      $imy="INSERT INTO `traveler`(`cardnumber`, `name`, `fathername`, `lastname`, `phon`, `chairset`, `prici`, `traveltarget`, `movehour`, `movedate`) 
                                    VALUES ('$card','$name','$fname','$lastname','$phone','$chiarnumber','$prici','$moves','$hour','$dates')";

$qur=mysqli_query($con,$imy);

 
}




    

    require('fpdf/fpdf.php');
    mysqli_set_charset($con,"utf8");

$pdf = new FPDF('p','mm','A4'); 

$pdf->AddPage();

$pdf->Image('img/fs.jpg',0,0,500);

$pdf->SetFont('Arial','B',16);
                $pdf->setFillColor(243,105,65);
$pdf->setTextColor (0,0,0);
$pdf->Image('img/dd.jpg',150,16);
$pdf->Image('img/logo.png',1,8);
$pdf->SetLeftMargin(59);
$pdf->SetTopMargin(300);
$pdf->LN(55);

$pdf->Cell(120,16,"Shamal Hamsafar bus Transportation");

$pdf->SetLeftMargin(26);
$pdf->SetX(50);
        $pdf->SetY(90);
                $pdf->LN();
                $pdf->SetFont('Arial','B',13);

             $pdf->setTextColor (20,20,0);
$pdf->Cell(90,10,"                      "."your are succssefuly registared!");


        $pdf->LN();
                $pdf->setFillColor(255,255,255);
             $pdf->setTextColor (0,0,0);
                             $pdf->SetFont('Arial','B',12);


$pdf->Cell(155,10,"        "."name  :"."   ".$name." ",1,1,'L',true);
$pdf->Cell(155,10,"        "."father name  :"."  ".$fname."",1,1,'L',true);
$pdf->Cell(155,10,"        "."lastname   :"."   ".$lastname."",1,1,'L',true);
$pdf->Cell(155,10,"        "."card number  :"."   ".$card."",1,1,'L',true);
$pdf->Cell(155,10,"        "."phone number  :"."    ".$phone."",1,1,'L',true);
$pdf->Cell(155,10,"        "."cost of teckat  :"."    ".$prici."",1,1,'L',true);
$pdf->Cell(155,10,"        "."chair number   :"."   ".$chiarnumber."",1,1,'L',true);
$pdf->Cell(155,10,"        "."chair number   :"."    ".$moves."",1,1,'L',true);

$pdf->Cell(155,10,"        "."move hour   :"."    ".$hour."",1,1,'L',true);
$pdf->Cell(155,10,"        "."move date   :"."     ".$dates."",1,1,'L',true);
  
$pdf->Output(); // Send to browser and display


    
    ?>

  <!-- cho "<div style='margin-top: 200px; margin-left: 90px; '>
    <p style='font-weight: bold;font-size: 18px; margin-left: 200px;color:blue'>شما موفقانه ثبت نمودید</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;'>نام شما :$name</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;>نام پدر :$fname</p>
<p style='font-weight: bold;font-size: 15px; margin-left: 200px;'>تخلض ::$lastname</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;'>نمبر تذکره :$card</p>
    <p style='font-weight: bold;font-size: 15px;  margin-left: 200px;'>شماره تلفن :$phone</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;'>قیمت تکت: :$prici</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;'>نمبر چوکی :$chiarnumber</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;'> ساعت حرکت :$hour</p>
    <p style='font-weight: bold;font-size: 15px; margin-left: 200px;'>تاریخ حرکت  :$dates</p>

 -->


    