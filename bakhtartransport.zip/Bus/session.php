	<?php

session_start();

function is_login(){


	if (!isset($_SESSION['user'])) {
		header("location:login.php");
	}
}


is_login();

?>