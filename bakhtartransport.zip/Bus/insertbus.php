<?php 
$con=mysqli_connect("localhost","root","","bakhtartransport")
 or die("dont conected to the server") ;

include("session.php");

if(isset($_POST["carnumber"])){
		$carnumber=$_POST['carnumber'];


$bus=$_POST['bus'];
$chiar=$_POST['chiar'];

$movehour=$_POST['movehour'];

	
echo "$bus";

      $imy="INSERT INTO `buslist`(`carnumber`, `name`, `amountchair`, `movehour`)
       VALUES ($carnumber,$bus,$chiar,$movehour)";
$qur=mysqli_query($con,$imy);

if($qur){
	header("location:hom.php");
}else{
	echo "dont insearted!";
}


}


?>