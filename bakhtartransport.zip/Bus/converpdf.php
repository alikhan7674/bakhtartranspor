<?Php
require('fpdf/fpdf.php');
$pdf = new FPDF(); 
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->SetFillColor(1,99,255); // input R ,G , B 
$pdf->SetTextColor(255,254,254);// input R , G , B 
$pdf->Cell(80,10,'Hello World!',1,0,'C',true,'https://www.plus2net.com');
$pdf->Output('report.pdf','I'); // Send to browser and display

?>