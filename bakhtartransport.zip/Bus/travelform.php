


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
		
<style type="text/css">
	@media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;

}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}

.row{margin-top:170px; text-align: center;
}
.row input{text-align: center;}
@media screen and (max-width: 500px) {
.contactForm .price-three .btn{
text-align: center;
margin-left: 50px;
margin-top: 0px;
}}
@media screen and (max-width: 500px) {
.row .contactForm table tr td input{
width: 360px;
display: inline-block;
}}
@media screen and (max-width: 700px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 800px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 900px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 1000px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 600px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 950px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 850px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 1100px) {
.row .contactForm input{
width: 360px;
}}
@media screen and (max-width: 1200px) {
.row .contactForm input{
width: 360px;
}}



.form-group { font-size: 18px;}
.form-group input{ font-size: 18px; width: 360px;}
.form-group table tr td select option{ font-size: 18px;}

.row .contactForm table tr td span{color: red;}

</style>
<script type="text/javascript">
  
  
function validatform() {
  // body...


var name=document.getElementById("name").value;
var card=document.getElementById("card").value;
var fname=document.getElementById("fname").value;
var lastname=document.getElementById("lastname").value;
var phon=document.getElementById("phon").value;
 var dates=document.getElementById("dates").value;
 var chnumber=document.getElementById("chnumber").value;
// var mo=document.getElementById("moves").value;

var validphon= new RegExp("07[0123456789][0-9]{7}");

//var valdat= new RegExp("[1-2]{2}-[1-3]{2}-202[2-9]{1}");

var valiname= new RegExp("[A-z]");
var valifname= new RegExp("[A-z]");
var valilastname= new RegExp("[A-z]");
var valda= new RegExp("202[2-5]{1}-[1-3]{1,2}-[1-2]{1,2}");
var digit = new RegExp("[0-9]");
var valphonp= new RegExp("[A-z]");

var valdates= new RegExp("[A-z]");

var valid=true;
if ( document.getElementById("hour").value=="select hour") {
    document.getElementById("hour").style.backgroundColor="rgb(250,160,130)";
    valid=false;

}else  {
      document.getElementById("hour").style.backgroundColor="white";


}
 if ( document.getElementById("moves").value=="select destination move") {
    document.getElementById("moves").style.backgroundColor="rgb(250,160,130)";
    valid=false;

}else  {
      document.getElementById("moves").style.backgroundColor="white";


}
if (card=="") {
  document.getElementById("card").style.backgroundColor="rgb(250,160,130)";
    document.getElementById("c").innerText=" *";


valid=false;

} else if (card.length<6|card.length>8) {
      document.getElementById("c").innerText=" کمتر از ۵عدد است ";

}

else{

document.getElementById("card").style.backgroundColor="white ";
    document.getElementById("c").innerText=" ";


}
 if (name=="") {

  document.getElementById("name").style.backgroundColor="rgb(250,160,130)";
      document.getElementById("n").innerText=" *";


  valid= false;
}else  if (digit.test(name)) {
      document.getElementById("n").innerText="نام عدد شده نمیتواند ";


valid=false;

}


else if (name.length<3) {

      document.getElementById("n").innerText="کمتر از ۳حروف است  ";


}else if (name.indexOf(" ")>-1) {

      document.getElementById("n").innerText="فاصله اجازه نیست  ";


}






else{

document.getElementById("name").style.backgroundColor="white ";
    document.getElementById("n").innerText=" ";


}
if (fname=="") {
  document.getElementById("fname").style.backgroundColor="rgb(250,160,130)";
        document.getElementById("fn").innerText=" *";


valid=false;

}else if (fname.length<3) {

      document.getElementById("fn").innerText="کمتر از ۳حروف است  ";


}else if (fname.indexOf(" ")>-1) {

      document.getElementById("fn").innerText="فاصله اجازه نیست  ";


}//else if (!valifname.test(fname)) {
//       document.getElementById("fn").innerText="نام عدد شده نمیتواند ";


// valid=false;

// }
else if (digit.test(fname)) {
      document.getElementById("fn").innerText="نام عدد شده نمیتواند ";


valid=false;

}


else{

document.getElementById("fname").style.backgroundColor="white ";
    document.getElementById("fn").innerText=" ";


}
if (lastname=="") {
  document.getElementById("lastname").style.backgroundColor="rgb(250,160,130)";
        document.getElementById("lasn").innerText=" *";


valid=false;

}else if (lastname.length<3) {

      document.getElementById("lasn").innerText="کمتر از ۳حروف است  ";


}else if (lastname.indexOf(" ")>-1) {

      document.getElementById("lasn").innerText="فاصله اجازه نیست  ";


}
// else if (!valilastname.test(lastname)) {
//       document.getElementById("lasn").innerText="نام عدد شده نمیتواند ";


// valid=false;

//} 
else if (digit.test(lastname)) {
      document.getElementById("lasn").innerText="نام عدد شده نمیتواند ";


valid=false;

}


else{

document.getElementById("lastname").style.backgroundColor="white ";
    document.getElementById("lasn").innerText=" ";


}
if (phon=="") {
  document.getElementById("phon").style.backgroundColor="rgb(250,160,130)";
        document.getElementById("ph").innerText=" *";


valid=false;

}else if (valphonp.test(phon)) {
      document.getElementById("ph").innerText="حروف شامل شماره تماس شده نمیتواند";


valid=false;

}




else if (phon.length<10|phon.length>10) {

      document.getElementById("ph").innerText="اندازه نمبر شما نادرست است  ";
valid=false;


}else if (!validphon.test(phon)) {
      document.getElementById("ph").innerText="فارمت نمبر نادرست است ";


valid=false;

}


else{

document.getElementById("phon").style.backgroundColor="white ";
    document.getElementById("ph").innerText=" ";


}
if (chnumber=="") {
  document.getElementById("chnumber").style.backgroundColor="rgb(250,160,130)";
        document.getElementById("chn").innerText=" *";


valid=false;

}else if (chnumber.length>2||chnumber>65) {

      document.getElementById("chn").innerText="!!!!این نمبر وجود ندارد  ";


}
// else if (!valch.test(chnumber)) {
//       document.getElementById("chn").innerText="این نمبر وجود ندارد";


// valid=false;

// }



else{

document.getElementById("chnumber").style.backgroundColor="white ";
    document.getElementById("chn").innerText=" ";


}
var parts=dates.split("-");
if (dates=="") {
  document.getElementById("dates").style.backgroundColor="rgb(250,160,130)";
        document.getElementById("da").innerText=" *";

valid=false;

} 
else if (valdates.test(dates)) {
      document.getElementById("da").innerText="حروف اجازه نیست ";


valid=false;

}

else if (dates.length<8) {

          document.getElementById("da").innerText=" at last 8!";

}
else if (parts.length==3) {


 if (parts[0].length !=4 ||parts[0]<2022||parts[0]>2023 ||parts[1].length>2 ||parts[1]<1||parts[1] >12||parts[2].length>2||parts[2]<1||parts[2] >31 ) {

document.getElementById("dates").style.backgroundColor="rgb(250,160,130)";
        document.getElementById("da").innerText=" تاریخ شما قابل اعتباز نیست !!!";


 valid=false;
}

}else if (parts.length!=3) {

        document.getElementById("da").innerText=" dont corrects";


}


else{

document.getElementById("dates").style.backgroundColor="white ";
    document.getElementById("da").innerText=" ";


}
window.setTimeout(hidspan,5000);
return valid;


}



function hidspan() {

  // body...
  document.getElementById("c").innerText=" ";
document.getElementById("n").innerText=" ";
document.getElementById("fn").innerText=" ";
document.getElementById("lasn").innerText=" ";
document.getElementById("chn").innerText=" ";
document.getElementById("ph").innerText=" ";
document.getElementById("da").innerText=" ";
document.getElementById("dates").style.backgroundColor="white ";
document.getElementById("card").style.backgroundColor="white ";
document.getElementById("name").style.backgroundColor="white ";
document.getElementById("chnumber").style.backgroundColor="white ";
document.getElementById("fname").style.backgroundColor="white ";
document.getElementById("lastname").style.backgroundColor="white ";
document.getElementById("phon").style.backgroundColor="white ";
document.getElementById("hour").style.backgroundColor="white ";
document.getElementById("moves").style.backgroundColor="white ";

 

}


</script>
  </head>
  <body>	
	
    <header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                        <li><a href="contact.php">ارتباط با ما</a></li> 
                                                <li><a href="agent.php">نماینده گی </a></li> 

                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>
 
                                                <li class="active"><a href="index.php">اصلی</a></li>

                      
                    </ul>
                </div>
            </div>
        </nav>		
    </header>	
       
  <div class="container">
        <div class="row">
      
      



                        <form action="registertravel.php" method="post" role="form" class="contactForm"   name="myForm"   onsubmit=" return (validatform());">

                                <div class="form-group">



                                  <table><tr><td>

                                  نمبر تذکره  : </td><td>
                                        <input type="number"
                                         name="card" 
                                             class="form-control" 

                                         autocomplete="off"

                                          id="card"
                                           placeholder="نمبر تذکرده" 
                                           />     

                                         </td>
                                         <td><span id="c"></span></td>
                                                 </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>



                                                 <tr><td>
                                
                                  نام مسافر :</td><td>
                                        <input type="text"
                                                 class="form-control" 


                                         autocomplete="off"  
                                         name="name" id="name"
                                          placeholder="نام مسافر " 
                                          /></td> 



                                    <td><span id="n"></span></td>



                                        </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                          <tr><td>
                                        
                                  نام پدر :</td><td>
                                        <input type="text" 

                                              class="form-control" 

                                        autocomplete="off" 
                                         name="fname"
                                          id="fname" 
                                          placeholder="نام پدر" 
                                           />    
                                            </td>
                                          <td><span id="fn"></span></td>


                                         </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                           <tr><td>

                                
                                  تخلص   :</td><td>
                                        <input type="text"
                                         autocomplete="off" 
                                                class="form-control" 
                                                onkeyup=" validatform();"

                                         name="lastname" 
                                         id="lastname" placeholder="تخلص " 
                                           />    
                                         </td>
                                         <td><span id="lasn"></span></td>


                                         </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                           <tr><td>

                                       
                                           شماره تلفن :</td><td>
                                        <input type="tel"
                                          name ="phon"
                                           autocomplete="off"

                                                    class="form-control" 

                                      id="phon" 
                                      placeholder="نمبر تلفن "
                                       
                                        />    </td>
                                     <td><span id="ph"></span></td>


                                      </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                        <tr><td>
                                        



                                  قیمت تکت :</td><td>
                                      <select  name="prici"  style="width: 360px;"               class="form-control"    >
                                          <option>
                                            600 af
                                          </option>
                                     
                                       
                                      </select> 
                                         </td>
                             <td><span id="pri"></span></td>



                                       </tr>  <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                      <tr><td>

                                        


                                  انتخاب ساعت حرکت :</td><td>
                                  <select name="hour" id="hour" style="width: 360px;"      class="form-control"        >
                                    <option value="select hour" >  select hour</option>
                                          <option >
                                            4 am
                                          </option>
                                           <option>
                                            8 am
                                          </option>
                                           <option>
                                            4 pm
                                          </option>
                                           <option>
                                            8 pm
                                          </option>
                                           

                                       
                                      </select>  
                                      </td>
                                <td><span id="h"></span></td>



                                    </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                      <tr><td>


                                  مقصد حرکت از :</td><td>
                                       <select    name="moves" id="moves" style="width: 360px;"         class="form-control"    >
                                        <option>select destination move</option>
                                         <option>kabul to mazar </option>
                                           <option>mazar to kabul </option>

                                       </select></td>
                                              <td><span id="mo"></span></td>


                                     </tr> <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                              <tr><td>

                                  نمبر چوکی  :</td><td>
                                        <input type="number"
                                          name="chnumber"

                                         class="form-control" 

                                           id="chnumber"
                                            placeholder="نمبر چوکی" data-rule="minlen:4"
                                               /></td>
                                                 <td><span id="chn"></span></td>
                                             </tr>
                                              <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>

                                                    <tr><td>

                                  تاریخ :</td><td>
                                        <input type="text" 
                                        name ="dates"
                                     autocomplete="off" 
                                          id="dates"
                                       placeholder="سال -ماه -روز " 
                                                                                class="form-control" 

                                       
                                        />  </td>
                                         <td><span id="da"></span></td>


                                      </tr>
                                              <tr>
                                                <td>
                                                  <p></p>
                                                </td>
                                              </tr>


                                         <tr>
                                          <td></td>
                                          <td>

                                      
                            <input type="submit" class="btn btn-theme pull-left" id="submit" value="اراجستر کردن " 
                                                                      class="form-control" style="width: 120px;" > 

                        <a href="">
                                <input  type="button" value="پرداخت از طریق حساب بانکی " class="btn btn-theme pull-left" style="margin-left: 30px; width: 210px;"      
                                  class="form-control" 
                                  >


                                </td></tr>

                                               
                   </table>
                    </div>


                        </form>
                      </div>
                    </div>
        </div>		
			  

		 <footer>
        <div class="social-icon">
            <div class="container">
                <div class="col-md-6 col-md-offset-3">                      
                    <ul class="social-network">
                        <li><a href="www.Facebook.com" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="www.twitter.com" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="Google.com" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="linkedin.com" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="ytube.com" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
                        <li><a href="dribbble.com" class="dribbble tool-tip" title="Dribbble"><i class="fa fa-dribbble"></i></a></li>
                        <li><a href="pinterest.com" class="pinterest tool-tip" title="Pinterest"><i class="fa fa-pinterest-square"></i></a></li>
                    </ul>                       
                </div>
            </div>
        </div>                      
        

</footer>
<script >
  
  $('#button').click(function(){

var doc=new jsPDF();
doc.save('report.pdf');
   });
</script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>