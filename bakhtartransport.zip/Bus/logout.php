
	<?php

session_start();


$_SESSION= array();
setcookie($_session_name(),time()-10000,'/');

session_destroy();

header("location:login.php")
?>