<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet"/>	

		<style type="text/css">
            @media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
.container p{font-size: 16px;}

	form {margin-left: 400px;margin-top:200px;}
		form  table tr td input{width: 290px;height: 25px;}
		form table tr th{font-weight: bold;font-size: 1.5vw;}
		body{background-color: lightblue}

	</style>
	<script type="text/javascript">
		function myfun() {
			var name=document.getElementById('name').value;
			var password=document.getElementById('password').value;
			if (name=="alireza"&&password=="1234") {
                window.open("home.html","_self")

			}else{
			var x=confirm("لطفا نام و یا پسورد شما غلط می باشد !");
			if(x)
			window.open("home.html","_self");
			else
						window.open("login.html","_self");

			}
			
		}
	</script>
  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>              
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                        <li><a href="contact.php">ارتباط با ما</a></li>  
                                                <li><a href="agent.php">نماینده گی </a></li> 

                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>

                                                <li class="active"><a href="index.php">اصلی</a></li>

                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->       
    </header><!--/header--> 
<div id="our-team">
        <div class="container">
            <div class="text-center">
                <h3>نماینده ما</h3>
                <p>اینها در صورت مشکلات به شما کمک می کند <br>و بهترین سهولت را برای شما فراهم می سازد </p>
            </div>
            <div class="row">
                <div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/1.png" alt="">
                        <h2>حبیب الله </h2>
                        <h4>مدیر</h4>
                        <p>0770180121:شماره تماس</p>
                    </div>
                </div>
                <div class="col-md-4 wow bounceInDown" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/2.png" alt="">
                        <h2>محمد </h2>
                        <h4>معاون</h4>
                        <p>0799055800 :شماره تماس</p>
                    </div>
                </div>
                <div class="col-md-4 wow fadeInUp" data-wow-offset="0" data-wow-delay="0.3s">
                    <div class="text-center">
                        <img src="img/team/3.png" alt="">
                        <h2>سخی </h2>
                        <h4>خلیفه </h4>
                        <p> 0747350839:شماره تماس</p>
                    </div>
                </div>  
            </div>
        </div>
        <footer>
        <div class="social-icon">
            <div class="container">
                <div class="col-md-6 col-md-offset-3">                      
                    <ul class="social-network">
                        <li><a href="www.Facebook.com" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="www.twitter.com" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="Google.com" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="linkedin.com" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="ytube.com" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
                        <li><a href="dribbble.com" class="dribbble tool-tip" title="Dribbble"><i class="fa fa-dribbble"></i></a></li>
                        <li><a href="pinterest.com" class="pinterest tool-tip" title="Pinterest"><i class="fa fa-pinterest-square"></i></a></li>
                    </ul>                       
                </div>
            </div>
        </div>                      
        

</footer>
    
   
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>