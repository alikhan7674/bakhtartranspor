<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet"/>	

		<style type="text/css">
      @media screen and (max-width: 991px) {
#header h1{
font-size:20px;
text-align: center;
}}
@media screen and (max-width: 1024px) {
#header h1{
font-size:24px;
}
}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}      }
@media screen and (max-width: 900px) {
#pricing  .row .wow .heading-one,.heading-two,.heading-three {
font-size:16px;
width: auto; height: 150px; text-align: center;
}      }
@media screen and (max-width: 900px) {
#pricing  .row .wow h2{
font-size:16px;
 text-align: center;
 margin-top: 40px;
}      }
@media screen and (max-width: 700px) {
#pricing  .row .wow .heading-one,.heading-two,.heading-three {
font-size:16px;
width: auto; height: 110px; text-align: center;
}      }
@media screen and (max-width: 700px) {
#pricing  .row .wow h2{
font-size:16px;
 text-align: center;
 margin-top: -5px;
}      }
@media screen and (max-width: 500px) {
#pricing  .row .wow .heading-one,.heading-two,.heading-three {
font-size:16px;
width: auto; height: 100px; text-align: center;
}      }
@media screen and (max-width: 500px) {
#pricing  .row .wow h2{
font-size:16px;
 text-align: center;
 margin-top: -5px;
 width: 400px;
 height: 99px;
}      }
@media screen and (max-width: 500px) {
#pricing  .row .wow span{
font-size:14px;
 text-align: center;
 margin-top: -5px;
}      }

</style>
</head>
  <body>    
    <header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>              
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                                                <li><a href="contact.php">ارتباط با ما</a></li>  
                                                <li><a href="agent.php">نماینده گی </a></li> 
s
                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>

                                                <li class="active"><a href="index.php">اصلی</a></li>

                        
                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->       
    </header><!--/header--> 




        </style>

  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>              
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                        <li><a href="contact.php">ارتباط با ما</a></li> 
                                                <li><a href="agent.php">نماینده گی </a></li> 

                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>
 
                                                <li class="active"><a href="index.php">اصلی</a></li>

                      
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->       
    </header><!--/header--> 
<div id="pricing">
        <div class="container">
            <div class="text-center">
                <h3>جدول قیمت ها </h3>
                <p> شما در اینجا میتوانید قیمت مورد علاقه تان را انتخاب نماید <br>
                و هرقسم که برای شما راحت است </p>
            </div>
            
            <div class="pricing-area text-center">
                <div class="row">
                    
                   
                      <div class="col-sm-4 plan price-one wow fadeInDown" data-wow-offset="0" data-wow-delay="0.2s">

                        <ul>
                            <li class="heading-one">
                                <h2>...درآینده </h2>
                            </li>
                            <li>دارای چوگی مناسب و راحت </li>
                            <li>وایفا دارد </li>
                            <li>شارچ گر موبایل دارد  </li>
                            <li>دستمال کاغذی دارد </li>
                            <li>تلویزیون دارد</li>
                            <li class="plan-action">
                                <a href="" class="btn btn-primary">ثبت  کردن</a>
                            </li>
                        </ul>
                    </div>
                      <div class="col-sm-4 plan price-one wow fadeInDown" data-wow-offset="0" data-wow-delay="0.2s">
                        <ul>
                            <li class="heading-one">
                                  <h2>...در آینده </h2>
                            </li>
                            <li>دارای چوگی مناسب و راحت</li>
                            <li>وایفا دارد </li>
                            <li>شارچ گر موبایل دارد  </li>
                            <li>دستمال کاغذی دارد </li>
                            <li>تلویزیون دارد</li>
                            <li class="plan-action">
                                <a href="" class="btn btn-primary">ثبت  کردن</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-sm-4 plan price-two wow fadeInDown" data-wow-offset="0" data-wow-delay="0.6s">

                        <ul>
                            <li class="heading-two">
                                  <h2>قیمت فی چوکی  600افغانی </h2>
                            </li>
                            <li>دارای چوگی مناسب و راحت</li>
                            <li>وایفا ندارد </li>
                            <li>شارچ گر موبایل دارد</li>
                            <li>دستمال کاغذی دارد</li>
                            <li>تلویزیون دارد</li>
                           <li class="plan-action">
                                <a href="travelform.php" class="btn btn-primary">ثبت  کردن</a>
                            </li>
                        </ul>
                   
                    
                </div>

                    
                </div>
            </div><!--/pricing-area-->          
        </div>
    </div><!--/#pricing-->
    
        <footer>
        <div class="social-icon">
            <div class="container">
                <div class="col-md-6 col-md-offset-3">                      
                    <ul class="social-network">
                        <li><a href="www.Facebook.com" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="www.twitter.com" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="Google.com" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="linkedin.com" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="ytube.com" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
                        <li><a href="dribbble.com" class="dribbble tool-tip" title="Dribbble"><i class="fa fa-dribbble"></i></a></li>
                        <li><a href="pinterest.com" class="pinterest tool-tip" title="Pinterest"><i class="fa fa-pinterest-square"></i></a></li>
                    </ul>                       
                </div>
            </div>
        </div>                      
        

</footer>
    
   
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>