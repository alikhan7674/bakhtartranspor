<?php
include("session.php");


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>شرکت ترانسپورت شمال همسفر</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/overwrite.css">
	<link href="css/animate.min.css" rel="stylesheet"> 
	<link href="css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="style.css">
		<style type="text/css">
		
@media screen and (max-width: 1024px) {
#header h1{
font-size:19px;
}}
@media screen and (max-width: 991px) {
#header h1{
font-size:18px;
text-align: center;
}}
 @media screen and (max-width: 900px) {
#header h1{font-size: 16px;}
}}
@media screen and (max-width: 500px) {
#header h1{
font-size:18px;
text-align: center;
}}
		 .p{margin-top: 130px;text-align: center;font-size: 20px; font-weight: bold;text-shadow: 1px 1px gray; color: blue;}

		 table tr td{font-size: 19px; }
.con{margin-top: 100px; text-align: center;margin-left: 500px;}
table{margin-left: 150px;}

@media screen and (max-width: 1600px) {
.con{
margin-left: 450px;
text-align: center;
margin-top: 10px;
}}
@media screen and (max-width: 1400px) {
.con{
margin-left: 300px;
text-align: center;
margin-top: 10px;
}}
@media screen and (max-width: 1600px) {
.p{
margin-left: 30px;
text-align: center;
margin-top: 120px;
}}
@media screen and (max-width: 1400px) {
.p{
margin-left: 30px;
text-align: center;
margin-top: 120px;
}}



@media screen and (max-width: 1200px) {
.con{
margin-left: 200px;
text-align: center;
margin-top: 10px;
}}


@media screen and (max-width: 1200px) {
.p{
margin-left: 30px;
text-align: center;
margin-top: 190px;
}}



@media screen and (max-width: 1100px) {
.con{
margin-left: 200px;
text-align: center;
margin-top: 10px;
}}

		 @media screen and (max-width: 1090px) {
.con{
margin-left: 250px;
text-align: center;
margin-top: 10px;
}}
		 @media screen and (max-width: 1100px) {
.con{
margin-left: 250px;
text-align: center;
margin-top: 20px;
}} @media screen and (max-width: 1100px) {
.p{
margin-left: 100px;
text-align: center;
margin-top: 170px;
}}
@media screen and (max-width: 1090px) {
.p{
margin-left: 100px;
text-align: center;
margin-top: 200px;
}}
@media screen and (max-width: 1000px) {
.p{margin-top: 120px;
text-align: center;
}}

 @media screen and (max-width: 990px) {
.p{margin-top: 150px;
text-align: center;
}}
 @media screen and (max-width: 900px) {
.p{margin-top: 160px;
text-align: center;
}}


		 @media screen and (max-width: 990px) {
.con{
margin-left: 200px;
text-align: center;
margin-top: 10px;
}}

@media screen and (max-width: 700px) {
.con{
margin-left: 50px;
text-align: center;

}}
@media screen and (max-width: 900px) {
table tr td{
	font-size: 14px;
text-align: center;
}}
@media screen and (max-width: 700px) {
table tr td{
	font-size: 14px;
text-align: center;
}}


		 @media screen and (max-width: 500px) {
.con {
font-size:10px;
text-align: center;
margin-left: 20px;
}}

 @media screen and (max-width: 500px) {
table tr td{
font-size:12px;
text-align: center;
}}
		 
	</style>

  </head>
  <body>	
	<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><img src="log.png">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h1 style="margin-top: -4px;">شرکت تراسپورت شمال همسفر </h1>
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">

                        <li><a href="contact.php">ارتباط با ما</a></li> 
                                                <li><a href="agent.php">نماینده گی </a></li> 
 
                                                <li><a href="prici.php">قیمت و برنامه ها </a> </li>

                                                <li><a href="galary.php">تصاویر</a></li>

                                              <li class="active"><a href="index.php">اصلی</a></li>

                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
	
				    
		
			<p class="p">صفحه مدیریت   </p>

	
				<div class="con">


<table>


	<tr>
		<td>مدیریت ایمل
		<a href="manegemail.php">
			<img src="photo/تغیرات ایمل.jpg">
		</a>
	</td>
	<td>تغیر رمز عبور
<a href="updateuser.php">
		<img src="photo/تغیر رمز عبور.jpg"></a>
	</td>

	</tr>
	<td>اضا فه کردن بس 
		<a href="insertcar.php">
			<img src="photo/bus.jpg" >
		</a>
	</td>
	
	<td>مدریت بس ها
		<a href="readcar.php">
			<img src="photo/bus.jpg">
		</a>
	</td>
	</tr>
	<tr>
		
		<td>لیست مسافرین 
		<a href="readtravel.php">
			<img src="photo/nam.png">
		</a>
	</td>
	<td>مدیریت نظرات
		<a href="manegcomet.php">
			<img src="photo/مدیریت نظرات.jpg">
		</a>
	</td>
	
<tr>
	
	<td>اضا فه  کردن موتروان  
		<a href="insertdiv.php">
		
	<img src="photo/nam.png"></a>
	</td><td>مدریت موتراون ها <a href="readderiver.php">
		<img  style="width: 80px; height: 40px;" src="photo/nam.png"></a>
		

	</td>
	
	</tr>
	</table>
</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>	
	<script src="js/parallax.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="js/fliplightbox.min.js"></script>
	<script src="js/functions.js"></script>
    <script src="contactform/contactform.js"></script>
    
</body>
</html>